package the.identity.grocery;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by LENOVO on 4/29/2016.
 */
public class dbhelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Grocery";
    public static final String TABLE_NAME = "list";
    public static final int VERSION = 1;
    public static final String KEY_ID = "_id";
    public static final String item = "item";
    public static final String qty = "qty";
    private ArrayList<String> results = new ArrayList<String>();
    public dbhelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
                db.execSQL("CREATE TABLE IF NOT EXISTS list(item VARCHAR,qty VARCHAR);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS list");
        onCreate(db);
    }
    public void add(String item,String qty){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("item", item);
        contentValues.put("qty", qty);
        db.insert("list", null, contentValues);
    }
    public void delete(String item){
        SQLiteDatabase db=this.getWritableDatabase();
       db.execSQL("delete from list where item='" + item + "';");
    }
    public String smsSend(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor res=db.rawQuery("select * from list", null);
        String re = "";
        if(res.moveToFirst())
        {
            do {
                re=re+ res.getString(0)+" "+res.getString(1)+", ";
            }
            while (res.moveToNext());
        }
        return re;
    }

    public ArrayList<String> view(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor res=db.rawQuery("select * from list",null);
        if(res.moveToFirst())
        {
            do {
                results.add("" + res.getString(0)+" " + res.getString(1));
            }
            while (res.moveToNext());
        }
        return results;
    }
    public void update(String item,String qty){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("item", item);
        contentValues.put("qty", qty);
        db.update("list",contentValues,"item=?",new String[]{item});
    }
}
