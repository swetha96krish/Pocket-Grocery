package the.identity.grocery;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by LENOVO on 4/29/2016.
 */
public class login extends AppCompatActivity {
    private EditText name,pwd;
    private Button login,signup;
    SQLiteDatabase usr;
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       /* name=(EditText)findViewById(R.id.name);
        pwd=(EditText)findViewById(R.id.pwd);
        login=(Button)findViewById(R.id.login);
        signup=(Button)findViewById(R.id.signup);*/
        usr=openOrCreateDatabase("details", Context.MODE_PRIVATE,null);
       // usr.execSQL("CREATE TABLE IF NOT EXISTS usr(name VARCHAR,address VARCHAR,phone VARCHAR,password VARCHAR);");
       /* login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c = usr.rawQuery("SELECT * FROM usr WHERE name='" + name.getText().toString() + "' And password='" + pwd.getText().toString() + "'", null);
                if (c.moveToFirst()) {
                    Intent i = new Intent(login.this, MainActivity.class);
                    startActivity(i);
                }
                else
                Toast.makeText(getApplicationContext(), "unsuccessfully", Toast.LENGTH_LONG).show();

            }
        });
    signup.setOnClickListener(new View.OnClickListener(){
            @Override
        public void onClick(View v){
                Intent i=new Intent(login.this, signup.class);
                startActivity(i);
            }
        });*/
        Cursor c=usr.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='usr';", null);
        if(c.moveToFirst())
        {
            Intent i = new Intent(login.this, MainActivity.class);
            startActivity(i);
        }
        else
        {
            Intent i=new Intent(login.this, signup.class);
            startActivity(i);
        }
    }
}
