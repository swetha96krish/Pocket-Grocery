package the.identity.grocery;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by LENOVO on 4/29/2016.
 */
public class signup extends AppCompatActivity {
    private EditText name,addr,phno,pwd;
    private Button signup;
    SQLiteDatabase usr;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        name=(EditText)findViewById(R.id.name);
        addr=(EditText)findViewById(R.id.addr);
        phno=(EditText)findViewById(R.id.phno);
        pwd=(EditText)findViewById(R.id.pwd);
        signup=(Button)findViewById(R.id.signup);
        usr=openOrCreateDatabase("details", Context.MODE_PRIVATE,null);
        usr.execSQL("CREATE TABLE IF NOT EXISTS usr(name VARCHAR,address VARCHAR,phone VARCHAR,password VARCHAR);");
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usr.execSQL("INSERT INTO usr VALUES('"+name.getText().toString()+"','"+addr.getText().toString()+"','"+phno.getText().toString()+"','"+pwd.getText().toString()+"');");;
               Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "" + smsSend());
                sendIntent.setType("text/plain");
               // sendIntent.setPackage("com.whatsapp");
                startActivity(sendIntent);
                Log.e("sms", "" + smsSend());
                Toast.makeText(getApplicationContext(), "successfully added",Toast.LENGTH_LONG).show();

                Intent i=new Intent(signup.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
    public String smsSend(){

        Cursor res=usr.rawQuery("select * from usr", null);
        String re = "";
        if(res.moveToFirst())
        {
                re="Name:"+ res.getString(0)+"\nAddress:"+res.getString(1);

        }
        return re;
    }

}
