package the.identity.grocery;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.support.v4.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by LENOVO on 4/29/2016.
 */
public class view extends AppCompatActivity {
Cursor cursor;
    AlertDialog alertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final dbhelper db=new dbhelper(this);
        final ListView l=(ListView)findViewById(R.id.lv);

       l.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, db.view()));
        l.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, final int position, long arg3) {
                alertDialog = new AlertDialog.Builder(view.this).create();

                alertDialog.setTitle("Dialog Button");

                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "delete", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {
                        db.delete((String) l.getItemAtPosition(position));
                        Toast.makeText(getApplicationContext(), "dele", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(view.this,MainActivity.class);
                        intent.putExtra("del","del");
                        startActivity(intent);

                    }
                });
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "update", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {

                        Intent intent = new Intent(view.this, add.class);
                        intent.putExtra("item", (String) l.getItemAtPosition(position));
                        startActivity(intent);
                    }
                });

                alertDialog.show();

            }
        });
        FloatingActionButton fab1 = (FloatingActionButton) findViewById(R.id.fab1);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "" + db.smsSend());
                sendIntent.setType("text/plain");
               // sendIntent.setPackage("com.whatsapp");
                startActivity(sendIntent);
                /*SmsManager sms=SmsManager.getDefault();
                sms.sendTextMessage("5556",null,""+db.smsSend(),null,null);*/
                Log.e("sms", "" + db.smsSend());
                Toast.makeText(getApplicationContext(), "sent", Toast.LENGTH_LONG).show();
                                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG).setAction("Action", null).show();

            }
        });

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                Intent i = new Intent(view.this, add.class);
                startActivity(i);
            }
        });
    }
}
