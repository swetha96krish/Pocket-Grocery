package the.identity.grocery;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LENOVO on 4/29/2016.
 */
public class add extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    private EditText item,qty;
    private Button add,up;
    private String met,firstWord;
    dbhelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        item=(EditText)findViewById(R.id.item);
        qty=(EditText)findViewById(R.id.qty);
        add=(Button)findViewById(R.id.add);
        up=(Button)findViewById(R.id.update);
        db=new dbhelper(this);
        Intent intent=getIntent();
        up.setVisibility(View.GONE);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);
        List<String> metric=new ArrayList<String>();
        metric.add("-");
        metric.add("g");
        metric.add("kg");
        metric.add("l");


        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, metric);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);
    final Bundle e=intent.getExtras();
        if(e!=null)
        {

            if(e.get("item").toString().contains(" ")){
                firstWord= e.get("item").toString().substring(0, e.get("item").toString().indexOf(" "));
            }
            item.setText(firstWord);
            add.setVisibility(View.GONE);
            up.setVisibility(View.VISIBLE);
            up.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(qty.getText().toString().trim().length()==0)
                    {
                        showMessage("Error", "Please enter all values");
                        return;
                    }
                    db.update(firstWord, qty.getText().toString()+met);
                    showMessage("Success", "Record updated");
                    clearText();
                }
            });
        }
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("Tag", "hi2");
                if(item.getText().toString().trim().length()==0||qty.getText().toString().trim().length()==0)
                {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                    db.add(item.getText().toString(), qty.getText().toString()+met);
                    Log.e("Tag", "hi3");
                    showMessage("Success", "Record added");
                    clearText();
            }
        });
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
        Intent i=new Intent(add.getContext(),view.class);
        startActivity(i);
    }
    public void clearText()
    {
        item.setText("");
        qty.setText("");

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    met= parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + met, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}

